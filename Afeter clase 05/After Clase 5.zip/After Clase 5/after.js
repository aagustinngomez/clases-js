/* Ejercicio 1: Cotizaciones
Codificar dos funciones:

Una función cotizarDolar(pesos), la cual recibe un valor monetario en pesos argentinos, y 
lo retorna en su equivalente en dólares.

Una función cotizarPesos(dolar), que recibe un valor monetario en dólares, y 
lo retorna en su equivalente en pesos argentinos.

Luego invocar las funciones solicitando  al usuario el valor y el tipo de cotización a realizar.
*/
const DOLAR_COMPRA=284;
const DOLAR_VENTA=288;

function cotizarDolar(pesos){
    let cotizacionDolares = pesos/DOLAR_COMPRA;
    return cotizacionDolares;
}

function cotizarPesos(dolar){
    let cotizacionPesos = dolar * DOLAR_VENTA;
    return cotizacionPesos;
}

let opcion = prompt("**** COTIZADOR ****\n1-De pesos a dolares\n2-De dolares a pesos");

if(opcion == "1"){
    let cantiPesos = parseFloat(prompt("Ingresa la cantidad de $"));
    let cotizacionD = cotizarDolar(cantiPesos);
    alert("Ingresando $"+cantiPesos+" te quedan U$S"+cotizacionD);
}else if(opcion == "2"){
    let cantiDolares = parseFloat(prompt("Ingresa la cantidad de U$S"));
    let cotizacionP = cotizarPesos(cantiDolares);
    alert("Ingresando U$S"+cantiDolares+" te quedan $"+cotizacionP);
}else{
    alert("Error en la opcion!");
}

/* Ejercicio 2: Tienda
Declarar un clase Tienda que permita registrar:
Nombre de la tienda.
Dirección de la tienda.
Propietario de la tienda.
Rubro de la tienda.
Luego invocar al menos tres (3) objetos usando esta clase.
*/

class Tienda{
    constructor(nombre,direccion,propietario,rubro){
        this.nombre = nombre;
        this.direccion = direccion;
        this.propietario = propietario;
        this.rubro = rubro;
    }
    //resolucion ej 3
    estaAbierto(hora){
        if((hora>=8 && hora<=12)||(hora>=15 && hora<=19)){
            return true;
        }else{
            return false;
        }
    }
}

const tienda1 = new Tienda("McDonald's","Av. Maipu 777","Ronald MC","Restaurant");
const tienda2 = new Tienda("Mostaza","9 de Julio 1090","Luis Ruiz","Restaurant");
const tienda3 = new Tienda("Coto","Uruguay 111","Alfredo Coto","Alimentos");

/* Ejercicio 3: Abierto/Cerrado
En base al ejercicio anterior: Declarar un método para la clase Tienda con la siguiente cabecera 
estaAbierto(hora). Este retorna true si la hora enviada está entre las 08 y 12, o entre las 15 y 19. 
Caso contrario, se retorna false.
Luego invocar al menos un (1) objeto usando esta clase, y solicitar al usuario tres (3) horas. 
Informar por alerta si la tienda está abierta, en función de la hora ingresada.
*/

for(let i=1;i<=3;i++){
    let horario = parseInt(prompt("Ingresa la hora en la que iras a la tienda"));
    let estadoTienda = tienda1.estaAbierto(horario);//true o false
    if(estadoTienda == true){
        alert("Te esperamos, la tienda está abierta!");
    }else{
        alert("La tienda está cerrada");
    }
}
