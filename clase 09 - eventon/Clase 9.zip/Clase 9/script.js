//EVENTOS DOM
const carrito = [];
const yerbaMate = {
    id:1,
    imagen:"./imagenes/yerba.jpg",
    nombre:"Yerba mate Taragui",
    descripcion:"Yerba mate con palo 1 Kg.",
    precio:800
}

let articuloTarjeta = document.getElementById("tarjetas");


articuloTarjeta.innerHTML = `
    <div class="card" style="width: 18rem;">
        <img src=${yerbaMate.imagen} class="card-img-top" alt=${yerbaMate.nombre}>
        <div class="card-body">
            <h5 class="card-title">${yerbaMate.nombre}</h5>
            <p class="card-text">${yerbaMate.descripcion}</p>
            <p class="card-text">Precio $ ${yerbaMate.precio}</p>
            <button id="miBoton" class="btn btn-primary">Comprar</button>
        </div>
    </div>
`;

let miBoton = document.getElementById("miBoton");

//OPCION 1
//miBoton.addEventListener("click",agregarAlCarro);

function agregarAlCarro(){
    alert("La yerba mate fue agregada con exito a su carrito!");
    carrito.push(yerbaMate);
    console.table(carrito);
}

//OPCION 2
miBoton.onclick = () => {
    agregarAlCarro();
}

miBoton.onmouseover = () => {
    console.log("Tenes ganas de un rico matecito?");
    miBoton.className = "btn btn-warning";
}

miBoton.onmouseout = () => {
    miBoton.className = "btn btn-primary";
}

//EVENTOS DE TECLADO
let campoNombre = document.getElementById("nombre");
let campoEdad = document.getElementById("edad");

campoEdad.onkeydown = () => {
    console.log("Se detecto la presion de una tecla!");
}

campoEdad.onkeyup = () => {
    console.log("Se detecto que se soltó una tecla!");
}

campoEdad.onchange = () => {
    console.log("Cambio el contenido - Contenido actualizado: " + campoEdad.value);
    if(campoEdad.value <= 0){
        alert("Edad inválida");
        campoEdad.value="";
    }
}

campoNombre.oninput = () => {
    if(isNaN(campoNombre.value)){
        //si no es un numero
        campoNombre.style.color="black";
    }else{
        campoNombre.style.color="red";
    }
}

//EVENTO SUBMIT
let formulario = document.getElementById("formulario");
formulario.addEventListener("submit",validar);

function validar(e){
    if((campoNombre.value=="")||(campoEdad.value=="")){
        e.preventDefault();//evitamos que se borren los campos porque faltan datos
        alert("Ingrese nombre o edad validos");
    }
}

//EVENTO DETECTANDO UNA TECLA ESPECIFICA
function capturarEnter(e){
    if(e.which == 13 || e.keycode == 13){
        alert("Presionaste el ENTER !!!");
    }
}